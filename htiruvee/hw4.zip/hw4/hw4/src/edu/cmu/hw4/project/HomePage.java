package edu.cmu.hw4.project;

import java.util.List;
import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.catalina.servlet4preview.RequestDispatcher;
import edu.cmu.hw4.databean.User;

/**
 * Servlet implementation class HomePage
 */
@WebServlet("/HomePage")
public class HomePage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HomePage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        if (user == null) {
            response.sendRedirect("Login");
            return;
        }

        List<String> errors = new ArrayList<String>();
        request.setAttribute("errors", errors);

        try {
        	if ("GET".equals(request.getMethod())) {
                RequestDispatcher d = (RequestDispatcher) request.getRequestDispatcher("HomePage.jsp");
                d.forward(request, response);
                return;
            }
            //errors.addAll(form.getValidationErrors());
            if (errors.size() > 0) {
                RequestDispatcher d = (RequestDispatcher) request.getRequestDispatcher("HomePage.jsp");
                d.forward(request, response);
                return;
            }
            
            RequestDispatcher d = (RequestDispatcher) request.getRequestDispatcher("todolist.jsp");
            d.forward(request, response);
        } 
        catch (Exception e) {
            errors.add(e.getMessage());
            RequestDispatcher d = (RequestDispatcher) request.getRequestDispatcher("error.jsp");
            d.forward(request, response);
        }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
